package com.apksandbox.core.staticanalysis

import com.android.tools.smali.dexlib2.DexFileFactory
import com.android.tools.smali.dexlib2.Opcodes
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import java.io.File

/**
 * Static scanner inspecting DEX method references and invocation instructions across 7 security categories.
 *
 * Implements:
 * - Direct inspection of instruction bytecodes (invoke-*) to capture exact calling classes and methods.
 * - Inspection of method reference tables for declared external dependencies.
 * - Categorization across 7 key security-sensitive surfaces.
 * - Explainable, neutral annotations distinguishing code references from executed behavior.
 * - Memory bounds and performance timeouts.
 */
object DexApiScanner {

    private const val MAX_FINDINGS_PER_CATEGORY = 200
    private const val MAX_TOTAL_FINDINGS = 1000
    private const val MAX_SCAN_TIME_MS = 30000L

    data class ApiRule(
        val category: ApiCategory,
        val targetClassDescriptor: String,
        val targetMethodNames: Set<String> = emptySet(),
        val explanation: String
    )

    private val RULES = listOf(
        // 1. Dynamic Code Loading
        ApiRule(
            category = ApiCategory.DYNAMIC_CODE_LOADING,
            targetClassDescriptor = "Ldalvik/system/DexClassLoader;",
            explanation = "Instantiates DexClassLoader to load classes dynamically from external JAR or APK files."
        ),
        ApiRule(
            category = ApiCategory.DYNAMIC_CODE_LOADING,
            targetClassDescriptor = "Ldalvik/system/PathClassLoader;",
            explanation = "Uses PathClassLoader to load classes or DEX archives from runtime filesystem paths."
        ),
        ApiRule(
            category = ApiCategory.DYNAMIC_CODE_LOADING,
            targetClassDescriptor = "Ldalvik/system/InMemoryDexClassLoader;",
            explanation = "Loads DEX bytecode directly from memory buffers without touching persistent storage."
        ),
        ApiRule(
            category = ApiCategory.DYNAMIC_CODE_LOADING,
            targetClassDescriptor = "Ljava/lang/ClassLoader;",
            targetMethodNames = setOf("loadClass", "defineClass"),
            explanation = "Invokes ClassLoader resolution methods to locate or define class implementations dynamically."
        ),

        // 2. Reflection
        ApiRule(
            category = ApiCategory.REFLECTION,
            targetClassDescriptor = "Ljava/lang/Class;",
            targetMethodNames = setOf("forName", "getMethod", "getDeclaredMethod", "getField", "getDeclaredField", "newInstance"),
            explanation = "Uses Java reflection to resolve classes, methods, or fields dynamically by name."
        ),
        ApiRule(
            category = ApiCategory.REFLECTION,
            targetClassDescriptor = "Ljava/lang/reflect/Method;",
            targetMethodNames = setOf("invoke"),
            explanation = "Dynamically invokes methods via Java Reflection."
        ),
        ApiRule(
            category = ApiCategory.REFLECTION,
            targetClassDescriptor = "Ljava/lang/reflect/Field;",
            targetMethodNames = setOf("get", "set", "setAccessible"),
            explanation = "Inspects or modifies object fields via reflection, potentially altering private members."
        ),

        // 3. Process Execution
        ApiRule(
            category = ApiCategory.PROCESS_EXECUTION,
            targetClassDescriptor = "Ljava/lang/Runtime;",
            targetMethodNames = setOf("exec"),
            explanation = "Spawns native operating system shell commands or external processes."
        ),
        ApiRule(
            category = ApiCategory.PROCESS_EXECUTION,
            targetClassDescriptor = "Ljava/lang/ProcessBuilder;",
            targetMethodNames = setOf("start"),
            explanation = "Constructs and executes child operating system processes."
        ),
        ApiRule(
            category = ApiCategory.PROCESS_EXECUTION,
            targetClassDescriptor = "Landroid/os/Process;",
            targetMethodNames = setOf("killProcess", "sendSignal"),
            explanation = "Interacts directly with Android Linux process management and signals."
        ),

        // 4. Native Library Loading
        ApiRule(
            category = ApiCategory.NATIVE_LIBRARY_LOADING,
            targetClassDescriptor = "Ljava/lang/System;",
            targetMethodNames = setOf("load", "loadLibrary"),
            explanation = "Loads compiled native shared libraries (.so ELF files) into the process memory space."
        ),
        ApiRule(
            category = ApiCategory.NATIVE_LIBRARY_LOADING,
            targetClassDescriptor = "Ljava/lang/Runtime;",
            targetMethodNames = setOf("load", "loadLibrary"),
            explanation = "Loads compiled native code via the Java Runtime interface."
        ),

        // 5. Accessibility APIs
        ApiRule(
            category = ApiCategory.ACCESSIBILITY,
            targetClassDescriptor = "Landroid/accessibilityservice/AccessibilityService;",
            explanation = "Extends or interacts with Android Accessibility Services which have broad UI observation capabilities."
        ),
        ApiRule(
            category = ApiCategory.ACCESSIBILITY,
            targetClassDescriptor = "Landroid/view/accessibility/AccessibilityNodeInfo;",
            targetMethodNames = setOf("performAction", "getText", "getContentDescription", "findAccessibilityNodeInfosByViewId"),
            explanation = "Queries or interacts with screen UI elements and text content through accessibility node interfaces."
        ),

        // 6. Device Administration
        ApiRule(
            category = ApiCategory.DEVICE_ADMINISTRATION,
            targetClassDescriptor = "Landroid/app/admin/DevicePolicyManager;",
            targetMethodNames = setOf("lockNow", "wipeData", "resetPassword", "installCaCert", "setCameraDisabled"),
            explanation = "Calls enterprise DevicePolicyManager administration APIs that control device locks, certificates, or storage."
        ),
        ApiRule(
            category = ApiCategory.DEVICE_ADMINISTRATION,
            targetClassDescriptor = "Landroid/app/admin/DeviceAdminReceiver;",
            explanation = "Implements device administration receiver for enterprise policy events."
        ),

        // 7. Sensitive Data Access
        ApiRule(
            category = ApiCategory.SENSITIVE_DATA_ACCESS,
            targetClassDescriptor = "Landroid/telephony/TelephonyManager;",
            targetMethodNames = setOf("getDeviceId", "getImei", "getSubscriberId", "getSimSerialNumber", "getLine1Number"),
            explanation = "Queries hardware device identifiers, SIM serials, or subscriber telephone metadata."
        ),
        ApiRule(
            category = ApiCategory.SENSITIVE_DATA_ACCESS,
            targetClassDescriptor = "Landroid/location/LocationManager;",
            targetMethodNames = setOf("getLastKnownLocation", "requestLocationUpdates"),
            explanation = "Accesses GPS or network provider location coordinates."
        ),
        ApiRule(
            category = ApiCategory.SENSITIVE_DATA_ACCESS,
            targetClassDescriptor = "Landroid/media/MediaRecorder;",
            targetMethodNames = setOf("setAudioSource", "start"),
            explanation = "Configures or initiates microphone audio capture."
        ),
        ApiRule(
            category = ApiCategory.SENSITIVE_DATA_ACCESS,
            targetClassDescriptor = "Landroid/content/ContentResolver;",
            targetMethodNames = setOf("query", "insert", "delete"),
            explanation = "Queries Android ContentProviders, which may include contacts, SMS, media, or calendar stores."
        )
    )

    data class ScanResult(
        val findings: List<ApiFinding>,
        val coverage: StaticAnalysisCoverage
    )

    fun scanApk(apkFile: File): ScanResult {
        val startTime = System.currentTimeMillis()
        val inspectedDexFiles = mutableListOf<String>()
        val skippedEntries = mutableListOf<String>()
        val parsingErrors = mutableListOf<String>()
        var limitsReached = false

        val findings = mutableListOf<ApiFinding>()
        val seenKeys = HashSet<String>()

        if (!apkFile.exists() || !apkFile.canRead()) {
            return ScanResult(
                findings = emptyList(),
                coverage = StaticAnalysisCoverage(
                    parsingErrors = listOf("APK file missing or unreadable: ${apkFile.absolutePath}"),
                    scanDurationMs = System.currentTimeMillis() - startTime
                )
            )
        }

        try {
            val opcodes = Opcodes.getDefault()
            val container = DexFileFactory.loadDexContainer(apkFile, opcodes)
            val entryNames = container.dexEntryNames.sorted()

            for (entryName in entryNames) {
                if (System.currentTimeMillis() - startTime > MAX_SCAN_TIME_MS) {
                    skippedEntries.add("$entryName (scan timeout exceeded)")
                    limitsReached = true
                    break
                }

                try {
                    val entry = container.getEntry(entryName) ?: continue
                    val dexFile = entry.dexFile
                    inspectedDexFiles.add(entryName)

                    if (dexFile is DexBackedDexFile) {
                        scanDexFile(dexFile, entryName, findings, seenKeys)
                    }

                    if (findings.size >= MAX_TOTAL_FINDINGS) {
                        limitsReached = true
                        break
                    }
                } catch (e: Exception) {
                    parsingErrors.add("$entryName: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            parsingErrors.add("DEX container load error: ${e.javaClass.simpleName}: ${e.message}")
        }

        val coverage = StaticAnalysisCoverage(
            dexFilesInspected = inspectedDexFiles,
            entriesSkipped = skippedEntries,
            parsingErrors = parsingErrors,
            limitsReached = limitsReached,
            scanDurationMs = System.currentTimeMillis() - startTime
        )

        return ScanResult(findings = findings, coverage = coverage)
    }

    private fun scanDexFile(
        dexFile: DexBackedDexFile,
        entryName: String,
        findings: MutableList<ApiFinding>,
        seenKeys: MutableSet<String>
    ) {
        // Step 1: Scan class bytecode for actual invocation instructions
        for (classDef in dexFile.classes) {
            val callingClass = classDef.type.removePrefix("L").removeSuffix(";").replace('/', '.')
            for (method in classDef.methods) {
                val impl = method.implementation ?: continue
                for (instruction in impl.instructions) {
                    if (instruction.opcode.name.startsWith("invoke-") && instruction is ReferenceInstruction) {
                        val ref = instruction.reference
                        if (ref is MethodReference) {
                            matchAndRecord(
                                ref = ref,
                                callingClass = callingClass,
                                callingMethod = method.name,
                                dexEntry = entryName,
                                isInvocation = true,
                                findings = findings,
                                seenKeys = seenKeys
                            )
                            if (findings.size >= MAX_TOTAL_FINDINGS) return
                        }
                    }
                }
            }
        }

        // Step 2: Also scan method reference section for table entries not caught by instruction walk
        try {
            val methodSection = dexFile.methodSection
            for (i in 0 until methodSection.size) {
                val methodRef = methodSection[i]
                matchAndRecord(
                    ref = methodRef,
                    callingClass = null,
                    callingMethod = null,
                    dexEntry = entryName,
                    isInvocation = false,
                    findings = findings,
                    seenKeys = seenKeys
                )
                if (findings.size >= MAX_TOTAL_FINDINGS) return
            }
        } catch (_: Exception) {
            // Method section reading failure is non-fatal
        }
    }

    private fun matchAndRecord(
        ref: MethodReference,
        callingClass: String?,
        callingMethod: String?,
        dexEntry: String,
        isInvocation: Boolean,
        findings: MutableList<ApiFinding>,
        seenKeys: MutableSet<String>
    ) {
        val definingClass = ref.definingClass
        val methodName = ref.name

        for (rule in RULES) {
            if (rule.targetClassDescriptor == definingClass) {
                if (rule.targetMethodNames.isEmpty() || rule.targetMethodNames.contains(methodName)) {
                    val formattedApi = "${definingClass.removePrefix("L").removeSuffix(";").replace('/', '.')}.$methodName"
                    val key = "$formattedApi|$callingClass|$callingMethod|$dexEntry|$isInvocation"
                    if (seenKeys.add(key)) {
                        val currentCategoryCount = findings.count { it.category == rule.category }
                        if (currentCategoryCount < MAX_FINDINGS_PER_CATEGORY) {
                            findings.add(
                                ApiFinding(
                                    apiName = formattedApi,
                                    category = rule.category,
                                    callingClass = callingClass,
                                    callingMethod = callingMethod,
                                    dexEntry = dexEntry,
                                    isInvocation = isInvocation,
                                    explanation = rule.explanation
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
