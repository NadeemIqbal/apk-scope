package com.apksandbox.core.staticanalysis

import java.io.Serializable

/**
 * Origin and relationship of an extracted URL candidate.
 */
enum class UrlProvenance : Serializable {
    /** Present in DEX string pool, but no direct code instruction reference resolved. */
    PRESENT_IN_DEX,
    /** Actively referenced by an opcode/instruction in method bytecode (e.g. const-string). */
    REFERENCED_BY_CODE,
    /** Cross-referenced destination observed during live Work Profile dynamic execution. */
    RUNTIME_OBSERVED
}

/**
 * Specific bytecode location where a URL, API, or string is referenced.
 */
data class CodeReferenceLocation(
    val dexEntry: String,
    val className: String,
    val methodName: String? = null,
    val isInstruction: Boolean = true
) : Serializable

/**
 * A structured URL candidate extracted from DEX files.
 */
data class DexUrlCandidate(
    val originalString: String,
    val normalizedUrl: String,
    val host: String,
    val scheme: String,
    val dexEntry: String,
    val provenance: UrlProvenance,
    val references: List<CodeReferenceLocation> = emptyList(),
    val extractionRule: String = "EXPLICIT_SCHEME"
) : Serializable

/**
 * Confidence level for SDK signature identification.
 */
enum class SdkConfidence : Serializable {
    HIGH,
    MEDIUM,
    LOW
}

/**
 * Detected third-party or platform SDK matching signature catalog rules.
 */
data class SdkFinding(
    val sdkName: String,
    val category: String,
    val confidence: SdkConfidence,
    val matchedSignatures: List<String>,
    val evidence: List<String>,
    val rationale: String,
    val catalogVersion: String = "1.0.0",
    val detectedVersion: String? = null
) : Serializable

/**
 * Category of security-relevant API references.
 */
enum class ApiCategory(val title: String) : Serializable {
    DYNAMIC_CODE_LOADING("Dynamic Code Loading"),
    REFLECTION("Reflection"),
    PROCESS_EXECUTION("Process Execution"),
    NATIVE_LIBRARY_LOADING("Native Library Loading"),
    ACCESSIBILITY("Accessibility APIs"),
    DEVICE_ADMINISTRATION("Device Administration"),
    SENSITIVE_DATA_ACCESS("Sensitive Data Access")
}

/**
 * An identified reference to or invocation of a security-sensitive API.
 */
data class ApiFinding(
    val apiName: String,
    val category: ApiCategory,
    val callingClass: String?,
    val callingMethod: String?,
    val dexEntry: String,
    val isInvocation: Boolean,
    val explanation: String
) : Serializable

/**
 * Execution coverage and bounded safety metrics for static DEX analysis.
 */
data class StaticAnalysisCoverage(
    val dexFilesInspected: List<String> = emptyList(),
    val entriesSkipped: List<String> = emptyList(),
    val parsingErrors: List<String> = emptyList(),
    val limitsReached: Boolean = false,
    val scanDurationMs: Long = 0L
) : Serializable
