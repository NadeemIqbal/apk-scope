package com.apksandbox.core.staticanalysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileOutputStream

class DexAnalysisTest {

    private fun findApk(relativePath: String): File? {
        val candidates = listOf(
            File("../../$relativePath"),
            File(relativePath),
            File("../$relativePath")
        )
        return candidates.firstOrNull { it.exists() && it.canRead() }
    }

    private fun findFixtureApk(): File {
        return findApk("fixture/build/outputs/apk/debug/fixture-debug.apk")
            ?: throw IllegalStateException("fixture-debug.apk not found; run :fixture:assembleDebug")
    }

    private fun findRiskFixtureApk(): File {
        return findApk("riskfixture/build/outputs/apk/debug/riskfixture-debug.apk")
            ?: throw IllegalStateException("riskfixture-debug.apk not found; run :riskfixture:assembleDebug")
    }

    @Test
    fun dexUrlExtractorHandlesNonExistentApkGracefully() {
        val badFile = File("non_existent_file.apk")
        val result = DexUrlExtractor.extractUrls(badFile)
        assertTrue("Should return empty URLs for missing APK", result.urls.isEmpty())
        assertTrue("Should record parsing error", result.coverage.parsingErrors.isNotEmpty())
    }

    @Test
    fun dexUrlExtractorHandlesCorruptedFileGracefully() {
        val tempCorrupt = File.createTempFile("corrupt", ".apk")
        try {
            FileOutputStream(tempCorrupt).use { fos ->
                fos.write("PK\u0003\u0004CorruptedZipEntryPayloadRandomGarbage".toByteArray())
            }
            val result = DexUrlExtractor.extractUrls(tempCorrupt)
            assertTrue("Should safely return empty or partial on corrupted file", result.urls.isEmpty())
            assertTrue("Should record parsing error for corrupt archive", result.coverage.parsingErrors.isNotEmpty())
        } finally {
            tempCorrupt.delete()
        }
    }

    @Test
    fun dexUrlExtractorExtractsUrlsAndIdentifiesProvenance() {
        val apkFile = findFixtureApk()

        val result = DexUrlExtractor.extractUrls(apkFile, observedRuntimeHosts = setOf("example.com"))
        assertTrue("Should inspect at least one classes.dex", result.coverage.dexFilesInspected.isNotEmpty())
        assertFalse("Limits should not be exceeded on small fixture", result.coverage.limitsReached)

        for (candidate in result.urls) {
            assertTrue("Scheme must be http, https, ws, or wss", candidate.scheme in listOf("http", "https", "ws", "wss"))
            assertTrue("Host must be non-empty", candidate.host.isNotBlank())
            assertFalse("Excluded schemas should not be present", candidate.originalString.startsWith("http://schemas.android.com/"))

            // Verify provenance logic
            if (candidate.host == "example.com") {
                assertEquals(UrlProvenance.RUNTIME_OBSERVED, candidate.provenance)
            } else if (candidate.references.isNotEmpty()) {
                assertEquals(UrlProvenance.REFERENCED_BY_CODE, candidate.provenance)
                val ref = candidate.references.first()
                assertTrue("Reference must have valid class name", ref.className.isNotBlank())
            } else {
                assertEquals(UrlProvenance.PRESENT_IN_DEX, candidate.provenance)
            }
        }
    }

    @Test
    fun dexUrlExtractorDeduplicatesWhilePreservingReferences() {
        val apkFile = findRiskFixtureApk()
        val result = DexUrlExtractor.extractUrls(apkFile)

        // Verify all extracted URLs are unique by normalized URL
        val urls = result.urls.map { it.normalizedUrl }
        val uniqueUrls = urls.toSet()
        assertEquals("Extracted candidate URLs must be deduplicated", uniqueUrls.size, urls.size)

        // Verify that candidates can have multiple distinct code references
        val multiRefCandidate = result.urls.firstOrNull { it.references.size > 1 }
        if (multiRefCandidate != null) {
            val distinctLocs = multiRefCandidate.references.map { "${it.className}->${it.methodName}" }.toSet()
            assertTrue("Multiple references should refer to code locations", distinctLocs.isNotEmpty())
        }
    }

    @Test
    fun sdkSignatureCatalogDetectsLibrariesAndAssignsConfidence() {
        val apkFile = findFixtureApk()

        val result = SdkSignatureCatalog.detectSdks(apkFile)
        assertTrue("Catalog version must be 1.0.0", SdkSignatureCatalog.CATALOG_VERSION == "1.0.0")
        assertTrue("Inspected DEX list should be non-empty", result.coverage.dexFilesInspected.isNotEmpty())

        for (sdk in result.sdks) {
            assertEquals("1.0.0", sdk.catalogVersion)
            assertTrue("SDK must have matched signatures", sdk.matchedSignatures.isNotEmpty())
            assertTrue("SDK must have evidence list", sdk.evidence.isNotEmpty())
            assertTrue("Rationale must be populated", sdk.rationale.isNotBlank())
            assertTrue("Confidence must be set", sdk.confidence in listOf(SdkConfidence.HIGH, SdkConfidence.MEDIUM, SdkConfidence.LOW))
        }

        // Verify OkHttp or BouncyCastle is detected if in classpath
        val detectedNames = result.sdks.map { it.sdkName }
        assertTrue("Must have scanned signatures without throwing", detectedNames.isNotEmpty() || result.coverage.dexFilesInspected.isNotEmpty())
    }

    @Test
    fun sdkSignatureCatalogNegativeMatch() {
        // An empty or minimal APK should not hallucinate unknown SDKs
        val tempEmpty = File.createTempFile("empty", ".apk")
        try {
            FileOutputStream(tempEmpty).use { fos ->
                fos.write("PK00".toByteArray())
            }
            val result = SdkSignatureCatalog.detectSdks(tempEmpty)
            assertTrue("Corrupted/empty archive should produce zero SDK detections", result.sdks.isEmpty())
        } finally {
            tempEmpty.delete()
        }
    }

    @Test
    fun dexApiScannerCategorizesSecurityApisAndDistinguishesInvocations() {
        val apkFile = findRiskFixtureApk()

        val result = DexApiScanner.scanApk(apkFile)
        assertTrue("DEX scan should inspect at least one DEX entry", result.coverage.dexFilesInspected.isNotEmpty())

        // Validate findings structure
        for (finding in result.findings) {
            assertTrue("API name must be non-empty", finding.apiName.isNotBlank())
            assertTrue("Explanation must be non-empty", finding.explanation.isNotBlank())
            assertTrue("DEX entry must end with .dex", finding.dexEntry.endsWith(".dex"))

            if (finding.isInvocation) {
                assertNotNull("Invocation findings should have calling class", finding.callingClass)
                assertNotNull("Invocation findings should have calling method", finding.callingMethod)
            }
        }

        // Verify categories are valid
        val categories = result.findings.map { it.category }.toSet()
        for (cat in categories) {
            assertTrue("Category must have title", cat.title.isNotBlank())
        }

        // Verify that riskfixture triggers sensitive categories (Reflection or Process Execution or Dynamic Loading)
        val categoryTitles = categories.map { it.title }
        val hasSecurityCategory = categoryTitles.any {
            it.contains("Reflection") || it.contains("Process") || it.contains("Dynamic") || it.contains("Native") || it.contains("Sensitive")
        }
        assertTrue("Risk fixture should trigger at least one security API category", hasSecurityCategory)
    }
}
